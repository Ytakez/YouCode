package com.opencode.ai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.opencode.ai.ui.components.AppDrawer
import com.opencode.ai.ui.theme.SurfaceContainerLowest
import com.opencode.ai.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

enum class Screen {
    CHAT, PROVIDERS, LOCAL_MODELS, SKILLS_MCP, SETTINGS
}

@Composable
fun MainScreen(viewModel: ChatViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var currentScreen by remember { mutableStateOf(Screen.CHAT) }
    var showModelPicker by remember { mutableStateOf(false) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppDrawer(
                sessions = viewModel.sessions,
                onNewChat = {
                    viewModel.newChat()
                    scope.launch { drawerState.close() }
                    currentScreen = Screen.CHAT
                },
                onSessionClick = { session ->
                    viewModel.loadSession(session)
                    scope.launch { drawerState.close() }
                    currentScreen = Screen.CHAT
                },
                onProvidersClick = {
                    scope.launch { drawerState.close() }
                    currentScreen = Screen.PROVIDERS
                },
                onSettingsClick = {
                    scope.launch { drawerState.close() }
                    currentScreen = Screen.SETTINGS
                },
                onModelsClick = {
                    scope.launch { drawerState.close() }
                    showModelPicker = true
                },
                onSkillsClick = {
                    scope.launch { drawerState.close() }
                    currentScreen = Screen.SKILLS_MCP
                },
                onLocalModelsClick = {
                    scope.launch { drawerState.close() }
                    currentScreen = Screen.LOCAL_MODELS
                }
            )
        },
        gesturesEnabled = true
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SurfaceContainerLowest)
        ) {
            when (currentScreen) {
                Screen.CHAT -> {
                    ChatScreen(
                        viewModel = viewModel,
                        onMenuClick = { scope.launch { drawerState.open() } },
                        onModelClick = { showModelPicker = true },
                        onProvidersClick = { currentScreen = Screen.PROVIDERS }
                    )
                }
                Screen.PROVIDERS -> {
                    ProvidersScreen(
                        onBack = { currentScreen = Screen.CHAT },
                        onLocalModelsClick = { currentScreen = Screen.LOCAL_MODELS }
                    )
                }
                Screen.LOCAL_MODELS -> {
                    LocalModelsScreen(onBack = { currentScreen = Screen.PROVIDERS })
                }
                Screen.SKILLS_MCP -> {
                    SkillsMcpScreen(onBack = { currentScreen = Screen.CHAT })
                }
                Screen.SETTINGS -> {
                    SettingsScreen(onBack = { currentScreen = Screen.CHAT }, viewModel = viewModel)
                }
            }

            AnimatedVisibility(
                visible = showModelPicker,
                enter = fadeIn() + slideInHorizontally { it },
                exit = fadeOut() + slideOutHorizontally { it }
            ) {
                ModelPickerScreen(
                    viewModel = viewModel,
                    onBack = { showModelPicker = false },
                    onModelSelected = {
                        viewModel.selectModel(it)
                        showModelPicker = false
                    }
                )
            }
        }
    }
}

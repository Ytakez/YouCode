package com.opencode.ai.data

import android.net.Uri

data class AiModel(
    val id: String,
    val name: String,
    val contextSize: String,
    val isFree: Boolean = true,
    val provider: String = "YouCode",
    val description: String = "",
    val isFavorite: Boolean = false
)

data class AttachedFile(
    val id: String,
    val name: String,
    val uri: Uri? = null,
    val mimeType: String = "text/plain",
    val sizeBytes: Long = 0,
    val contentPreview: String = "",
    val isSavedByAi: Boolean = false
)

data class ChatMessage(
    val id: String,
    val content: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val modelName: String? = null,
    val attachments: List<AttachedFile> = emptyList()
)

data class ChatSession(
    val id: String,
    val title: String,
    val lastMessage: String,
    val timestamp: Long,
    val messages: List<ChatMessage> = emptyList()
)

data class LocalModel(
    val id: String,
    val name: String,
    val vendor: String,
    val description: String,
    val sizeGb: Float,
    val minRamGb: Int,
    val isDownloaded: Boolean = false,
    val downloadProgress: Float = 0f
)

data class ProviderItem(
    val id: String,
    val name: String,
    val description: String,
    val category: String, // "opencode" | "local" | "key"
    val needsKey: Boolean = false
)

data class SkillItem(
    val id: String,
    val name: String,
    val description: String
)

data class McpServer(
    val id: String,
    val name: String,
    val url: String = ""
)


data class SmartMode(
    val id: String,
    val name: String,
    val emoji: String,
    val description: String,
    val preferredModelIds: List<String>,
    val systemHint: String
)

object SampleData {
    
    val smartModes = listOf(
        SmartMode(
            "auto", "Авто", "✨",
            "Сам выбирает модель под задачу",
            listOf("deepseek-v4.1", "hy4-flash", "minimax-m3.1"),
            "Ты универсальный помощник. Подстраивайся под задачу."
        ),
        SmartMode(
            "code", "Программирование", "💻",
            "Лучшие модели для кода. При лимите — следующая",
            listOf("deepseek-v4.1", "flint-40b", "glm-5.3", "hy4-flash"),
            "Ты senior-разработчик. Пиши чистый код, объясняй кратко, предлагай лучшие практики."
        ),
        SmartMode(
            "study", "Учёба", "📚",
            "Объяснения, конспекты, подготовка к экзаменам",
            listOf("longcat-2.5", "nemotron-3.5-super", "hy4-flash"),
            "Ты терпеливый преподаватель. Объясняй просто, с примерами, проверяй понимание."
        ),
        SmartMode(
            "design", "Дизайн", "🎨",
            "UI/UX, цвета, типографика, макеты",
            listOf("minimax-m3.1", "beam", "inkling-2"),
            "Ты продуктовый дизайнер. Думай о иерархии, доступности, трендах Material Design 3."
        ),
        SmartMode(
            "write", "Тексты", "✍️",
            "Статьи, посты, письма, сценарии",
            listOf("longcat-2.5", "hy4-flash", "iceman"),
            "Ты сильный редактор и копирайтер. Пиши ясно, живо, без воды."
        ),
        SmartMode(
            "translate", "Перевод", "🌐",
            "Точный перевод и адаптация",
            listOf("hy4-flash", "longcat-2.5", "deepseek-v4.1"),
            "Ты профессиональный переводчик. Сохраняй смысл и стиль оригинала."
        ),
        SmartMode(
            "math", "Математика", "🔢",
            "Задачи, формулы, пошаговые решения",
            listOf("deepseek-v4.1", "flint-40b", "nemotron-3.5-lightning"),
            "Ты математик. Решай пошагово, проверяй ответ, объясняй логику."
        ),
        SmartMode(
            "business", "Бизнес", "📊",
            "Стратегия, аналитика, презентации",
            listOf("minimax-m3.1", "longcat-2.5", "hy4-flash"),
            "Ты бизнес-консультант. Думай структурированно, давай actionable советы."
        ),
        SmartMode(
            "creative", "Креатив", "🎭",
            "Идеи, истории, брейншторм",
            listOf("beam", "iceman", "inkling-2"),
            "Ты креативный директор. Предлагай неожиданные идеи, развивай образы."
        ),
        SmartMode(
            "research", "Исследование", "🔬",
            "Поиск фактов, сравнение, анализ",
            listOf("nemotron-3.5-super", "deepseek-v4.1", "longcat-2.5"),
            "Ты исследователь. Опирайся на факты, сравнивай источники, указывай неопределённость."
        ),
        SmartMode(
            "legal", "Документы", "📄",
            "Договоры, заявления, формальные тексты",
            listOf("longcat-2.5", "hy4-flash", "glm-5.3"),
            "Ты помогаешь с формальными документами. Пиши чётко и структурированно. Это не юрконсультация."
        ),
        SmartMode(
            "health", "Здоровье", "🩺",
            "Общая информация о ЗОЖ (не медицина)",
            listOf("nemotron-3.5-super", "hy4-flash"),
            "Давай общую информацию о здоровье и ЗОЖ. Всегда напоминай обратиться к врачу."
        ),
        SmartMode(
            "travel", "Путешествия", "✈️",
            "Маршруты, советы, чек-листы",
            listOf("beam", "minimax-m3.1", "hy4-flash"),
            "Ты travel-эксперт. Помогай с маршрутами, бюджетом и практическими советами."
        ),
        SmartMode(
            "fast", "Быстрый ответ", "⚡",
            "Коротко и по делу, минимальный расход",
            listOf("hy4-flash", "iceman", "mimo-v2.6"),
            "Отвечай максимально кратко и по делу."
        ),
    )

    val freeModels = listOf(
        AiModel("hy4-flash", "Hy4 flash Free", "1M", true, "YouCode"),
        AiModel("iceman", "Iceman Free", "262k", true, "YouCode"),
        AiModel("inkling-2", "Inkling 2 Small Free", "1M", true, "YouCode"),
        AiModel("longcat-2.5", "LongCat 2.5 Free", "1M", true, "YouCode"),
        AiModel("flint-40b", "Flint 40B Free", "262k", true, "YouCode"),
        AiModel("minimax-m3.1", "MiniMax M3.1 Flash Free", "1M", true, "YouCode"),
        AiModel("deepseek-v4.1", "DeepSeek V4.1 Flash Free", "200k", true, "YouCode"),
        AiModel("nemotron-3.5-super", "Nemotron 3.5 Super VL Free", "1M", true, "YouCode"),
        AiModel("beam", "Beam Free", "1M", true, "YouCode"),
        AiModel("mimo-v2.6", "MiMo-V2.6-Flash Free", "200k", true, "YouCode"),
        AiModel("glm-5.3", "GLM-5.3-Flash Free", "200k", true, "YouCode"),
        AiModel("nemotron-3.5-lightning", "Nemotron 3.5 Lightning Free", "1M", true, "YouCode"),
    )

    val localModels = listOf(
        LocalModel("gemma4-e2b", "Gemma 4 E2B", "Google", "точнее мобильной", 3.1f, 8),
        LocalModel("gemma4-e4b-mobile", "Gemma 4 E4B (мобильная)", "Google", "умнее E2B, для телефонов с 8 ГБ памяти", 3.2f, 8),
        LocalModel("gemma4-e4b", "Gemma 4 E4B", "Google", "лучшая из маленьких, для 12 ГБ памяти и больше", 5.0f, 12),
        LocalModel("qwen35-2b", "Qwen 3.5 2B", "Alibaba", "самая лёгкая", 1.3f, 4),
        LocalModel("qwen35-4b", "Qwen 3.5 4B", "Alibaba", "хорошо работает с инструментами", 2.7f, 6),
    )

    val providers = listOf(
        ProviderItem("opencode-go", "OpenCode Go", "Подписка opencode: Kimi, GLM, DeepSeek, Qwen, MiniMax и другие открытые модели за фиксированную цену.", "opencode"),
        ProviderItem("opencode-zen", "OpenCode Zen", "Аккаунт opencode: бесплатные модели, а с балансом все модели Zen, включая Claude, GPT и Gemini.", "opencode"),
        ProviderItem("claude", "Claude", "Подписка Claude Pro или Max через официальный Claude Code.", "opencode"),
        ProviderItem("local", "Модели на телефоне", "Gemma 4, Qwen и другие, без интернета и бесплатно", "local"),
        ProviderItem("302ai", "302.AI", "API-ключ", "key", true),
        ProviderItem("50x", "50X", "API-ключ", "key", true),
        ProviderItem("abacus", "Abacus", "API-ключ", "key", true),
        ProviderItem("abliterated", "AbliteratedLLM", "API-ключ", "key", true),
    )

    val skills = listOf(
        SkillItem("opencode", "OpenCode", "Use this skill for any question about OpenCode itself, including how OpenCode works, using or configuring it, migrating from V1 to V2, trouble..."),
        SkillItem("report", "Report", "Use when the user wants to report an opencode issue or bug. Collect standard diagnostics, add user-specific reproduction context, and publi..."),
    )

    val sampleSessions = listOf(
        ChatSession("1", "Greeting", "Привет! Как дела?", System.currentTimeMillis() - 3600000),
        ChatSession("2", "Знакомство", "Расскажи о себе", System.currentTimeMillis() - 7200000),
        ChatSession("3", "Запуск сервера", "Как запустить Node.js сервер?", System.currentTimeMillis() - 86400000),
        ChatSession("4", "Greeting", "Hello again", System.currentTimeMillis() - 172800000),
    )
}

package com.opencode.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Material Design 3 dark palette — refined, expensive Google-level feel
// Primary: soft luminous mint
val md_theme_dark_primary = Color(0xFF86EFAC)
val md_theme_dark_onPrimary = Color(0xFF00391C)
val md_theme_dark_primaryContainer = Color(0xFF005229)
val md_theme_dark_onPrimaryContainer = Color(0xFFA7F3C0)

// Secondary
val md_theme_dark_secondary = Color(0xFFB4CCB8)
val md_theme_dark_onSecondary = Color(0xFF1F3528)
val md_theme_dark_secondaryContainer = Color(0xFF354B3D)
val md_theme_dark_onSecondaryContainer = Color(0xFFD0E8D3)

// Tertiary — cool teal for accents
val md_theme_dark_tertiary = Color(0xFF9CD0D6)
val md_theme_dark_onTertiary = Color(0xFF00363C)
val md_theme_dark_tertiaryContainer = Color(0xFF1E4D53)
val md_theme_dark_onTertiaryContainer = Color(0xFFB8ECF2)

// Error
val md_theme_dark_error = Color(0xFFFFB4AB)
val md_theme_dark_errorContainer = Color(0xFF93000A)
val md_theme_dark_onError = Color(0xFF690005)
val md_theme_dark_onErrorContainer = Color(0xFFFFDAD6)

// Surfaces — deep neutral with subtle green undertone (expensive dark)
val md_theme_dark_background = Color(0xFF0B0F0D)
val md_theme_dark_onBackground = Color(0xFFE2E3DF)
val md_theme_dark_surface = Color(0xFF0B0F0D)
val md_theme_dark_onSurface = Color(0xFFE2E3DF)
val md_theme_dark_surfaceVariant = Color(0xFF3F4942)
val md_theme_dark_onSurfaceVariant = Color(0xFFBFC9C0)
val md_theme_dark_outline = Color(0xFF89938A)
val md_theme_dark_outlineVariant = Color(0xFF3F4942)
val md_theme_dark_inverseOnSurface = Color(0xFF0B0F0D)
val md_theme_dark_inverseSurface = Color(0xFFE2E3DF)
val md_theme_dark_inversePrimary = Color(0xFF006D3A)
val md_theme_dark_surfaceTint = Color(0xFF86EFAC)
val md_theme_dark_scrim = Color(0xFF000000)

// Tonal surface containers (MD3 elevation system)
val SurfaceContainerLowest = Color(0xFF060908)
val SurfaceContainerLow = Color(0xFF131815)
val SurfaceContainer = Color(0xFF171C19)
val SurfaceContainerHigh = Color(0xFF212622)
val SurfaceContainerHighest = Color(0xFF2C312D)

// Semantic accents
val FreeBadge = Color(0xFF4ADE80)
val FreeBadgeBg = Color(0xFF14532D)
val FileChipBg = Color(0xFF1E3A2F)
val FileChipBorder = Color(0xFF2E5A45)
val SuccessGreen = Color(0xFF34D399)
val WarningAmber = Color(0xFFFBBF24)
